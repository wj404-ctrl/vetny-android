# Vetny

Voice assistant for Android. Clap twice -> weather greeting -> talk to Claude -> "open Spotify" opens it.

## Run it
1. Open this folder in Android Studio and let Gradle sync.
2. Plug in your phone (USB debugging on) and press Run.
3. In the app: allow mic, location, notifications; tap "Allow opening apps"; paste your Anthropic API key; tap "Save key and start Vetny".

## Where to change things
| I want to...                          | Edit                          |
|---------------------------------------|-------------------------------|
| Change personality / greeting         | `Config.kt` (PERSONA, greetingPrompt) |
| Use a smarter or faster model         | `Config.kt` (MODEL)           |
| Make claps more/less sensitive        | `Config.kt` (CLAP_THRESHOLD)  |
| Change the voice                      | `Config.kt` (VOICE_HINTS, pitch, rate) |
| Celsius instead of Fahrenheit         | `Config.kt` (FAHRENHEIT)      |
| Give Vetny a new ability              | `Tools.kt` (add one Tool)     |
| Turn web search on/off                | `Config.kt` (WEB_SEARCH)      |
| Change what / how much she remembers  | `Config.kt` (MAX_FACTS, REFLECT) |
| Turn code running on/off              | `Config.kt` (CODE_EXECUTION)  |
| Change the screen                     | `MainActivity.kt`             |

## Add an ability in one block (Tools.kt)
```kotlin
Tool("get_time", "Get the current time.", emptyMap()) { _, _ ->
    java.text.SimpleDateFormat("h:mm a", java.util.Locale.US).format(java.util.Date())
},
```
Claude sees the description and decides when to call it. Whatever string you return is what it uses to answer.

## File map
- `Config.kt` all settings
- `Tools.kt` abilities Claude can use
- `Brain.kt` Claude API call and tool loop
- `VetnyService.kt` background service and conversation flow
- `ClapDetector.kt` double-clap detection
- `Voice.kt` speech out and speech in
- `Weather.kt`, `AppLauncher.kt`, `Prefs.kt`, `MainActivity.kt`

## Memory and skills
- Vetny remembers things you tell her ("I like lo-fi when I work") and counts which apps you open most.
- She learns skills: teach her a routine ("when I say good morning, open Spotify and give me the weather") or let her notice a repeated one, and she saves it and reuses it.
- After every conversation she quietly reviews it and saves anything worth keeping (turn off with REFLECT = false; it costs one extra API call).
- See, or wipe, everything with the "What does Vetny remember?" button in the app. Code: `Memory.kt`.
- Memory is stored on the phone, but a summary of it is sent to Anthropic with each request. She is told not to save passwords, money or health details unless you ask.

## Notes
- Code running uses Anthropic's sandbox, not your phone. It has no internet and can't touch your files. Paste code into the scratchpad in the app, then say "run the code I pasted". If the API rejects the tool, check CODE_EXEC_TOOL / CODE_EXEC_BETA against the current Anthropic code execution docs.
- Web search uses Anthropic's built-in search tool. An admin must enable it in the Anthropic Console (Settings > Privacy), and searches are billed per use.
- Open the app now and then so the saved location (used for weather) stays fresh.
- Turn off battery optimization for Vetny so Android doesn't kill the listener.
- The API key is stored in app-private storage, unencrypted.
