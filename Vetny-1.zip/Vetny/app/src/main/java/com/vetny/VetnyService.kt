package com.vetny

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class VetnyService : Service() {

    companion object {
        const val ACTION_STOP = "com.vetny.STOP"
        private const val CHANNEL = "vetny"
        private const val TAG = "Vetny"
        private val GOODBYE = Config.GOODBYE
    }

    private var detector: ClapDetector? = null
    private lateinit var voice: Voice
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var alive = true
    @Volatile private var busy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        voice = Voice(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Vetny is listening", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, VetnyService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stopPi
        ).build()
        val notif = Notification.Builder(this, CHANNEL)
            .setContentTitle("Vetny")
            .setContentText("Clap twice to wake me")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(stopAction)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notif)
        }
        if (!busy && detector?.isAlive != true) startDetector()
        return START_STICKY
    }

    private fun startDetector() {
        if (!alive) return
        detector?.shutdown()
        detector = ClapDetector { onClap() }.also { it.start() }
    }

    private fun onClap() {
        busy = true
        Thread {
            try { session() } catch (e: Exception) { Log.e(TAG, "session failed", e) }
            busy = false
            main.post { startDetector() }
        }.start()
    }

    private fun session() {
        val brain = Brain(this, Prefs.apiKey(this))
        val weather = Weather.summary(this)
        val time = SimpleDateFormat("EEEE h:mm a", Locale.US).format(Date())

        val greeting = try {
            brain.chat(Config.greetingPrompt(time, weather))
        } catch (e: Exception) {
            Log.e(TAG, "greeting failed", e)
            "Hey! " + (weather ?: "I couldn't get the weather.") +
                " Also, I can't reach my brain, so check the API key in the app."
        }
        voice.speak(greeting)

        for (turn in 0 until Config.MAX_TURNS) {
            val heard = voice.listen()?.trim().orEmpty()
            if (heard.isEmpty()) break
            if (GOODBYE.containsMatchIn(heard)) { voice.speak("Later!"); break }
            val reply = try {
                brain.chat(heard)
            } catch (e: Exception) {
                Log.e(TAG, "chat failed", e)
                "Sorry, I couldn't reach my brain. Check your API key and connection."
            }
            voice.speak(reply)
        }
        Thread {
            try { brain.reflect() } catch (e: Exception) { Log.e(TAG, "reflect failed", e) }
        }.start()
    }

    override fun onDestroy() {
        alive = false
        detector?.shutdown()
        voice.shutdown()
        super.onDestroy()
    }
}
