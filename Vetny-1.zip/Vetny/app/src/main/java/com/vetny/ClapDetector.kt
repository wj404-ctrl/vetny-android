package com.vetny

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.SystemClock
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Listens to the mic and calls [onDoubleClap] when it hears two sharp loud
 * sounds 150-700 ms apart. The mic is released BEFORE the callback fires so the
 * speech recognizer can take it.
 *
 * Tune ABS_THRESHOLD (lower = more sensitive) if claps are missed or false triggers happen.
 */
class ClapDetector(private val onDoubleClap: () -> Unit) : Thread("vetny-clap") {

    companion object {
        const val ABS_THRESHOLD = Config.CLAP_THRESHOLD
        const val FLOOR_MULTIPLIER = Config.CLAP_FLOOR_MULTIPLIER
        const val MIN_GAP_MS = Config.CLAP_MIN_GAP_MS
        const val MAX_GAP_MS = Config.CLAP_MAX_GAP_MS
    }

    @Volatile private var running = true
    fun shutdown() { running = false }

    @SuppressLint("MissingPermission")
    override fun run() {
        val sampleRate = 16000
        val frame = 320 // 20 ms
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
            max(minBuf, frame * 8)
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return }

        val buf = ShortArray(frame)
        var floor = 300.0
        var armed = true
        var firstClap = 0L
        var triggered = false

        try {
            rec.startRecording()
            while (running && !triggered) {
                val n = rec.read(buf, 0, frame)
                if (n <= 0) continue
                var sum = 0.0
                for (i in 0 until n) { val s = buf[i].toDouble(); sum += s * s }
                val rms = sqrt(sum / n)
                val threshold = max(ABS_THRESHOLD, floor * FLOOR_MULTIPLIER)
                val now = SystemClock.elapsedRealtime()

                if (rms > threshold) {
                    if (armed) {
                        armed = false
                        val gap = now - firstClap
                        if (firstClap != 0L && gap in MIN_GAP_MS..MAX_GAP_MS) {
                            triggered = true
                        } else {
                            firstClap = now
                        }
                    }
                } else {
                    if (rms < threshold * 0.5) armed = true
                    floor = floor * 0.99 + rms * 0.01
                }
                if (firstClap != 0L && now - firstClap > MAX_GAP_MS) firstClap = 0L
            }
        } finally {
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
        }
        if (triggered && running) onDoubleClap()
    }
}
