package com.vetny

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Weather {
    /** Plain-English weather summary, or null if no location / network. Call off the main thread. */
    fun summary(ctx: Context): String? {
        val (lat, lon) = Prefs.location(ctx) ?: return null
        return try {
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,apparent_temperature,weather_code" +
                "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                "&temperature_unit=${if (Config.FAHRENHEIT) "fahrenheit" else "celsius"}&timezone=auto&forecast_days=1"
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            val json = JSONObject(conn.inputStream.bufferedReader().readText())
            val cur = json.getJSONObject("current")
            val daily = json.getJSONObject("daily")
            val temp = Math.round(cur.getDouble("temperature_2m"))
            val feels = Math.round(cur.getDouble("apparent_temperature"))
            val hi = Math.round(daily.getJSONArray("temperature_2m_max").getDouble(0))
            val lo = Math.round(daily.getJSONArray("temperature_2m_min").getDouble(0))
            val pop = daily.getJSONArray("precipitation_probability_max").optInt(0, 0)
            "Right now it's $temp degrees (feels like $feels) and ${describe(cur.getInt("weather_code"))}. " +
                "Today's high is $hi, low is $lo, with a $pop percent chance of precipitation."
        } catch (e: Exception) {
            null
        }
    }

    private fun describe(code: Int) = when (code) {
        0 -> "clear"
        1 -> "mostly clear"
        2 -> "partly cloudy"
        3 -> "overcast"
        45, 48 -> "foggy"
        51, 53, 55, 56, 57 -> "drizzling"
        61, 63, 65, 66, 67 -> "rainy"
        71, 73, 75, 77 -> "snowy"
        80, 81, 82 -> "showery"
        85, 86 -> "snow showers"
        95, 96, 99 -> "stormy"
        else -> "mixed conditions"
    }
}
