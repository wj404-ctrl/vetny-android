package com.vetny

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Vetny's long-term memory, stored on the phone in app-private storage:
 *  - facts:  things she learned about you ("likes lo-fi playlists in the evening")
 *  - skills: routines she learned ("morning routine": open Spotify, read the news)
 *  - apps:   how often you open each app
 * A summary is added to Claude's instructions every time she wakes up.
 */
object Memory {
    private const val FILE = "vetny_memory.json"

    private fun load(ctx: Context): JSONObject {
        val o = try { JSONObject(File(ctx.filesDir, FILE).readText()) } catch (e: Exception) { JSONObject() }
        if (!o.has("facts")) o.put("facts", JSONArray())
        if (!o.has("skills")) o.put("skills", JSONArray())
        if (!o.has("apps")) o.put("apps", JSONObject())
        return o
    }

    private fun save(ctx: Context, o: JSONObject) = File(ctx.filesDir, FILE).writeText(o.toString())

    private fun strings(a: JSONArray) = (0 until a.length()).map { a.getString(it) }
    private fun objects(a: JSONArray) = (0 until a.length()).map { a.getJSONObject(it) }

    // ---------- facts ----------
    @Synchronized fun addFact(ctx: Context, text: String): String {
        val t = text.trim()
        if (t.isEmpty()) return "Nothing to remember."
        val o = load(ctx)
        val facts = strings(o.getJSONArray("facts")).toMutableList()
        if (facts.any { it.equals(t, ignoreCase = true) }) return "Already knew that."
        facts.add(t)
        while (facts.size > Config.MAX_FACTS) facts.removeAt(0)
        o.put("facts", JSONArray(facts))
        save(ctx, o)
        return "Remembered."
    }

    @Synchronized fun removeFact(ctx: Context, topic: String): String {
        val q = topic.trim().lowercase()
        if (q.isEmpty()) return "Nothing to forget."
        val o = load(ctx)
        val facts = strings(o.getJSONArray("facts"))
        val kept = facts.filterNot { it.lowercase().contains(q) }
        o.put("facts", JSONArray(kept))
        save(ctx, o)
        return "Forgot ${facts.size - kept.size} thing(s)."
    }

    // ---------- skills ----------
    @Synchronized fun saveSkill(ctx: Context, name: String, description: String, instructions: String): String {
        val key = name.trim().lowercase()
        if (key.isEmpty() || instructions.isBlank()) return "A skill needs a name and instructions."
        val o = load(ctx)
        val skills = objects(o.getJSONArray("skills")).toMutableList()
        var uses = 0
        skills.removeAll { s ->
            val same = s.getString("name") == key
            if (same) uses = s.optInt("uses", 0)
            same
        }
        skills.add(
            JSONObject().put("name", key).put("description", description.trim())
                .put("instructions", instructions.trim()).put("uses", uses)
        )
        while (skills.size > Config.MAX_SKILLS) skills.removeAt(0)
        o.put("skills", JSONArray(skills))
        save(ctx, o)
        return "Skill saved: $key."
    }

    @Synchronized fun useSkill(ctx: Context, name: String): String {
        val key = name.trim().lowercase()
        val o = load(ctx)
        val skills = objects(o.getJSONArray("skills"))
        val s = skills.firstOrNull { it.getString("name") == key }
            ?: skills.firstOrNull { it.getString("name").contains(key) }
            ?: return "No skill named \"$name\". Known skills: ${skills.joinToString { it.getString("name") }.ifEmpty { "none" }}."
        s.put("uses", s.optInt("uses", 0) + 1)
        save(ctx, o)
        return "Skill ${s.getString("name")}: ${s.getString("instructions")}"
    }

    @Synchronized fun deleteSkill(ctx: Context, name: String): String {
        val key = name.trim().lowercase()
        val o = load(ctx)
        val skills = objects(o.getJSONArray("skills"))
        val kept = skills.filterNot { it.getString("name") == key }
        o.put("skills", JSONArray(kept))
        save(ctx, o)
        return if (kept.size < skills.size) "Deleted skill $key." else "No skill named $key."
    }

    // ---------- habits ----------
    @Synchronized fun countApp(ctx: Context, label: String) {
        val o = load(ctx)
        val apps = o.getJSONObject("apps")
        apps.put(label, apps.optInt(label, 0) + 1)
        save(ctx, o)
    }

    // ---------- views ----------
    /** Added to Claude's instructions on every call. */
    @Synchronized fun promptBlock(ctx: Context): String {
        val o = load(ctx)
        val sb = StringBuilder()
        val facts = strings(o.getJSONArray("facts"))
        if (facts.isNotEmpty()) {
            sb.append("WHAT YOU KNOW ABOUT THE USER:\n")
            facts.forEach { sb.append("- ").append(it).append('\n') }
        }
        val apps = o.getJSONObject("apps")
        val top = apps.keys().asSequence().map { it to apps.getInt(it) }.sortedByDescending { it.second }.take(5).toList()
        if (top.isNotEmpty()) sb.append("MOST-OPENED APPS: ").append(top.joinToString { "${it.first} (${it.second})" }).append('\n')
        val skills = objects(o.getJSONArray("skills"))
        if (skills.isNotEmpty()) {
            sb.append("SKILLS YOU HAVE LEARNED (call use_skill with the name to get the steps):\n")
            skills.forEach { sb.append("- ${it.getString("name")}: ${it.getString("description")} (used ${it.optInt("uses", 0)}x)\n") }
        }
        return sb.toString().ifBlank { "You don't know anything about the user yet." }
    }

    /** Human-readable dump for the app screen. */
    @Synchronized fun dump(ctx: Context): String {
        val o = load(ctx)
        val sb = StringBuilder("WHAT I KNOW\n")
        strings(o.getJSONArray("facts")).ifEmpty { listOf("(nothing yet)") }.forEach { sb.append("• $it\n") }
        sb.append("\nSKILLS\n")
        val skills = objects(o.getJSONArray("skills"))
        if (skills.isEmpty()) sb.append("(none yet)\n")
        skills.forEach { sb.append("• ${it.getString("name")}: ${it.getString("instructions")}\n") }
        val apps = o.getJSONObject("apps")
        sb.append("\nAPPS I OPENED FOR YOU\n")
        val list = apps.keys().asSequence().map { it to apps.getInt(it) }.sortedByDescending { it.second }.toList()
        if (list.isEmpty()) sb.append("(none yet)\n")
        list.forEach { sb.append("• ${it.first}: ${it.second}x\n") }
        return sb.toString()
    }

    @Synchronized fun clear(ctx: Context) { File(ctx.filesDir, FILE).delete() }
}
