package com.vetny

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("vetny", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("api_key", "") ?: ""
    fun setApiKey(c: Context, key: String) = sp(c).edit().putString("api_key", key.trim()).apply()

    fun scratch(c: Context): String = sp(c).getString("scratch", "") ?: ""
    fun setScratch(c: Context, text: String) = sp(c).edit().putString("scratch", text).apply()

    fun saveLocation(c: Context, lat: Double, lon: Double) =
        sp(c).edit().putString("lat", lat.toString()).putString("lon", lon.toString()).apply()

    fun location(c: Context): Pair<Double, Double>? {
        val la = sp(c).getString("lat", null)?.toDoubleOrNull()
        val lo = sp(c).getString("lon", null)?.toDoubleOrNull()
        return if (la != null && lo != null) la to lo else null
    }
}
