package com.vetny

import android.content.Context
import android.content.Intent

object AppLauncher {
    fun open(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(query, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val q = name.trim().lowercase()
        val match = apps.firstOrNull { it.first.lowercase() == q }
            ?: apps.firstOrNull { it.first.lowercase().startsWith(q) }
            ?: apps.firstOrNull { it.first.lowercase().contains(q) }
            ?: return "No installed app matches \"$name\"."
        val intent = pm.getLaunchIntentForPackage(match.second)
            ?: return "${match.first} can't be launched."
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(intent)
            Memory.countApp(ctx, match.first)
            "Opened ${match.first}."
        } catch (e: Exception) {
            "Android blocked opening ${match.first}. The overlay permission may be missing."
        }
    }
}
