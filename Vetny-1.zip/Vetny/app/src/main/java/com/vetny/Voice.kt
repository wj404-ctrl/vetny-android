package com.vetny

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/** Text-to-speech (US female voice) and speech recognition. speak()/listen() block, so call them off the main thread. */
class Voice(private val ctx: Context) {

    companion object {
        // Google US voice codes that sound female. Reorder to taste, or pick a voice in
        // Settings > System > Languages > Text-to-speech output.
        val VOICE_HINTS = Config.VOICE_HINTS
    }

    private val main = Handler(Looper.getMainLooper())
    private val ready = CountDownLatch(1)
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) configure()
            ready.countDown()
        }
    }

    private fun configure() {
        val t = tts ?: return
        t.language = Locale.US
        t.setPitch(Config.VOICE_PITCH)
        t.setSpeechRate(Config.VOICE_RATE)
        val us = t.voices.orEmpty().filter { it.locale == Locale.US }
        val pick = VOICE_HINTS.firstNotNullOfOrNull { hint ->
            us.firstOrNull { it.name.contains(hint, ignoreCase = true) }
        } ?: us.firstOrNull()
        if (pick != null) t.voice = pick
    }

    fun speak(text: String) {
        ready.await(5, TimeUnit.SECONDS)
        val t = tts ?: return
        val done = CountDownLatch(1)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { done.countDown() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { done.countDown() }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
        done.await(60, TimeUnit.SECONDS)
    }

    /** Returns what the user said, or null on silence / error. */
    fun listen(): String? {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) return null
        val latch = CountDownLatch(1)
        val result = AtomicReference<String?>(null)
        val recRef = AtomicReference<SpeechRecognizer?>(null)

        main.post {
            val rec = SpeechRecognizer.createSpeechRecognizer(ctx)
            recRef.set(rec)
            rec.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onError(error: Int) { latch.countDown() }
                override fun onResults(results: Bundle?) {
                    result.set(
                        results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    )
                    latch.countDown()
                }
            })
            rec.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            )
        }
        latch.await(20, TimeUnit.SECONDS)
        main.post { recRef.get()?.destroy() }
        return result.get()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
