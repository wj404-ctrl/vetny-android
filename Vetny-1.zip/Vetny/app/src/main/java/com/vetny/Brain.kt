package com.vetny

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Talks to Claude (Anthropic Messages API). Settings are in Config.kt, abilities in Tools.kt. */
class Brain(private val ctx: Context, private val apiKey: String) {

    private val history = JSONArray()

    /** Sends a user turn and returns what Vetny should say. Call off the main thread. */
    fun chat(userText: String): String {
        history.put(JSONObject().put("role", "user").put("content", userText))
        var spoken = ""
        repeat(4) {
            val resp = call()
            val content = resp.getJSONArray("content")
            val stop = resp.optString("stop_reason")
            history.put(JSONObject().put("role", "assistant").put("content", content))

            val text = StringBuilder()
            val results = JSONArray()
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                when (block.getString("type")) {
                    "text" -> text.append(block.getString("text"))
                    "tool_use" -> results.put(
                        JSONObject()
                            .put("type", "tool_result")
                            .put("tool_use_id", block.getString("id"))
                            .put("content", Tools.run(ctx, block.getString("name"), block.getJSONObject("input")))
                    )
                }
            }
            if (text.isNotBlank()) spoken = text.toString()
            if (results.length() == 0 && stop != "pause_turn") return spoken.trim().ifEmpty { "Done!" }
            if (results.length() > 0) history.put(JSONObject().put("role", "user").put("content", results))
        }
        return spoken.trim().ifEmpty { "Done!" }
    }

    /** Learning loop: after a conversation, review it and save new memories and skills. */
    fun reflect() {
        if (!Config.REFLECT || history.length() < 4) return
        chat(Config.REFLECT_PROMPT)
    }

    private fun call(): JSONObject {
        val body = JSONObject()
            .put("model", Config.MODEL)
            .put("max_tokens", Config.MAX_TOKENS)
            .put("system", Config.PERSONA + "\n\n" + Memory.promptBlock(ctx))
            .put("tools", Tools.schema())
            .put("messages", history)

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 10000
        conn.readTimeout = 30000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", apiKey)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        if (Config.CODE_EXECUTION) conn.setRequestProperty("anthropic-beta", Config.CODE_EXEC_BETA)
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        val text = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().readText()
        if (code !in 200..299) throw IOException("HTTP $code: $text")
        return JSONObject(text)
    }
}
