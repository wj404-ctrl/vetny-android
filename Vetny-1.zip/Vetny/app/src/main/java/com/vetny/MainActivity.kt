package com.vetny

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var keyField: EditText
    private lateinit var scratch: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        fun add(v: android.view.View) = root.addView(
            v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        add(TextView(this).apply { text = "Vetny"; textSize = 32f })
        add(TextView(this).apply { text = "Clap twice and I'll wake up."; setPadding(0, 0, 0, pad) })

        keyField = EditText(this).apply {
            hint = "Anthropic API key (sk-ant-...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(Prefs.apiKey(this@MainActivity))
        }
        add(keyField)

        scratch = EditText(this).apply {
            hint = "Code scratchpad: paste code here, then say \"run the code I pasted\""
            minLines = 4
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setText(Prefs.scratch(this@MainActivity))
        }
        add(scratch)

        add(Button(this).apply {
            text = "Save key and start Vetny"
            setOnClickListener { start() }
        })
        add(Button(this).apply {
            text = "Allow opening apps (overlay permission)"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        })
        add(Button(this).apply {
            text = "What does Vetny remember?"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Vetny\u2019s memory")
                    .setMessage(Memory.dump(this@MainActivity))
                    .setPositiveButton("Close", null)
                    .setNeutralButton("Clear all") { _, _ -> Memory.clear(this@MainActivity) }
                    .show()
            }
        })
        add(Button(this).apply {
            text = "Stop Vetny"
            setOnClickListener {
                startService(Intent(this@MainActivity, VetnyService::class.java).setAction(VetnyService.ACTION_STOP))
                refreshStatus()
            }
        })
        status = TextView(this).apply { setPadding(0, pad, 0, 0) }
        add(status)

        setContentView(ScrollView(this).apply { addView(root) })

        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)
        refreshLocation()
    }

    override fun onPause() {
        super.onPause()
        Prefs.setScratch(this, scratch.text.toString())
    }

    override fun onResume() {
        super.onResume()
        refreshLocation()
        refreshStatus()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshLocation()
        refreshStatus()
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun start() {
        Prefs.setApiKey(this, keyField.text.toString())
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            status.text = "Microphone permission is needed first."
            return
        }
        startForegroundService(Intent(this, VetnyService::class.java))
        refreshStatus()
    }

    private fun refreshStatus() {
        fun mark(ok: Boolean) = if (ok) "✓" else "✗"
        status.text = listOf(
            "${mark(granted(Manifest.permission.RECORD_AUDIO))} Microphone",
            "${mark(Prefs.apiKey(this).isNotEmpty())} API key saved",
            "${mark(Prefs.location(this) != null)} Location saved (for weather)",
            "${mark(Settings.canDrawOverlays(this))} Overlay permission (for opening apps)"
        ).joinToString("\n")
    }

    private fun refreshLocation() {
        if (!granted(Manifest.permission.ACCESS_COARSE_LOCATION)) return
        val lm = getSystemService(LocationManager::class.java) ?: return
        try {
            val last = listOf(
                LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER
            ).mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
                .maxByOrNull { it.time }
            if (last != null) {
                Prefs.saveLocation(this, last.latitude, last.longitude)
            } else if (Build.VERSION.SDK_INT >= 30) {
                lm.getCurrentLocation(LocationManager.NETWORK_PROVIDER, null, mainExecutor) { loc ->
                    if (loc != null) {
                        Prefs.saveLocation(this, loc.latitude, loc.longitude)
                        refreshStatus()
                    }
                }
            }
        } catch (_: Exception) {
        }
    }
}
