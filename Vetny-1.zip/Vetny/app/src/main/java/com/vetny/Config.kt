package com.vetny

/**
 * Everything you're likely to tweak lives here.
 * Change a value, press Run in Android Studio, done.
 */
object Config {

    // ---------- Brain (Claude) ----------
    /** Fast model = snappy voice. For smarter answers try "claude-sonnet-5-5". */
    const val MODEL = "claude-haiku-5-5"
    const val MAX_TOKENS = 1500

    /**
     * Lets Claude write and run Python/shell code in Anthropic's sandbox (not on your phone).
     * Tool version and beta header come from Anthropic's code execution docs; update them here if they change.
     */
    const val CODE_EXECUTION = true
    const val CODE_EXEC_TOOL = "code_execution_20250825"
    const val CODE_EXEC_BETA = "code-execution-2025-08-25"

    /** Lets Claude search the web for current info (news, scores, prices, facts). */
    const val WEB_SEARCH = true
    const val WEB_SEARCH_MAX_USES = 3

    /** Vetny's personality. Replies are spoken aloud, so keep them short and plain. */
    const val PERSONA = "You are Vetny, a voice assistant living on the user's Android phone. " +
        "Personality: a cool, upbeat, quick-witted American girl. Casual, warm, a little playful, never cringe. " +
        "Everything you write is read aloud by text-to-speech, so reply in one to three short sentences, " +
        "with no markdown, no lists, no emoji, and no symbols that sound weird out loud. " +
        "When you have a tool that fits the request, call it, then confirm in a few words. " +
        "For anything current or that you're not sure about (news, scores, prices, facts), search the web, " +
        "then give a short spoken answer without reading out links or sources. " +
        "You can also run Python and shell code in a sandbox to calculate, analyze data, or test code. " +
        "When asked to run or check code, do it and say the result in plain words. " +
        "If the user says code they pasted, read the scratchpad first. " +
        "Never read code aloud line by line; say what it does and what happened. " +
        "If asked for something you can't do, say so honestly instead of pretending. " +
        "You have long-term memory and learnable skills (listed below if you have any). Use what you know naturally, " +
        "and never announce that you are checking memory. When the user shares a lasting preference or habit, or says " +
        "remember this, call remember. When the user teaches you a routine, or you finish a multi-step task they will " +
        "likely repeat, call save_skill with clear step-by-step instructions. When a request matches a skill, call " +
        "use_skill and follow it. If asked to forget something, call forget. " +
        "Never store passwords, financial details or health details unless the user explicitly asks you to."

    /** What Claude is told when you wake Vetny. */
    fun greetingPrompt(time: String, weather: String?) =
        "[wake-up] I just woke you up. Local time: $time. Weather: ${weather ?: "unavailable"}. " +
            "Greet me warmly and give me the weather in two short sentences, then ask what I need."

    // ---------- Memory and skills ----------
    const val MAX_FACTS = 60
    const val MAX_SKILLS = 25

    /** After each conversation, Vetny quietly reviews it and saves new memories and skills (learning loop). */
    const val REFLECT = true
    const val REFLECT_PROMPT = "[session ended] Quietly review this conversation. If you learned a lasting preference " +
        "or habit about me, call remember. If I taught you, or you completed, a multi-step routine I'm likely to " +
        "repeat, call save_skill (this updates an existing skill with the same name). Skip sensitive details like " +
        "passwords, money or health unless I asked. Reply with only: ok"

    // ---------- Wake-up (double clap) ----------
    const val CLAP_THRESHOLD = 2500.0   // lower = more sensitive (max 32767)
    const val CLAP_FLOOR_MULTIPLIER = 6.0
    const val CLAP_MIN_GAP_MS = 150L
    const val CLAP_MAX_GAP_MS = 700L

    // ---------- Voice ----------
    /** Google US voice codes that sound female. Reorder to taste. */
    val VOICE_HINTS = listOf("tpf", "sfg", "iob", "tpc")
    const val VOICE_PITCH = 1.08f
    const val VOICE_RATE = 1.05f

    // ---------- Conversation ----------
    const val MAX_TURNS = 8
    /** Saying any of these ends the conversation. */
    val GOODBYE = Regex("\\b(bye|goodbye|that's all|never mind|stop listening)\\b", RegexOption.IGNORE_CASE)

    // ---------- Weather ----------
    const val FAHRENHEIT = true
}
