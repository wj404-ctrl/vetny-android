package com.vetny

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** One thing Claude is allowed to do on the phone. */
class Tool(
    val name: String,
    val description: String,
    /** parameter name -> what it means */
    val params: Map<String, String>,
    val run: (Context, JSONObject) -> String
)

/**
 * HOW TO ADD A NEW ABILITY: add one Tool(...) to the list below. Nothing else to change.
 *
 * Example:
 *   Tool("get_time", "Get the current time.", emptyMap()) { _, _ ->
 *       java.text.SimpleDateFormat("h:mm a", java.util.Locale.US).format(java.util.Date())
 *   },
 */
object Tools {
    val all = listOf(
        Tool(
            name = "open_app",
            description = "Open an installed app on the user's phone by its name, e.g. Spotify, Camera, Maps.",
            params = mapOf("app_name" to "The app's name")
        ) { ctx, args -> AppLauncher.open(ctx, args.optString("app_name")) },

        Tool(
            name = "read_scratchpad",
            description = "Read the code or text the user pasted into the scratchpad in the Vetny app.",
            params = emptyMap()
        ) { ctx, _ -> Prefs.scratch(ctx).ifBlank { "The scratchpad is empty." } },

        Tool(
            name = "remember",
            description = "Save a lasting fact or preference about the user, as one short sentence.",
            params = mapOf("fact" to "The fact, e.g. \"Likes lo-fi playlists in the evening\"")
        ) { ctx, args -> Memory.addFact(ctx, args.optString("fact")) },

        Tool(
            name = "forget",
            description = "Forget saved facts that mention a topic.",
            params = mapOf("topic" to "A word or phrase that appears in the fact to forget")
        ) { ctx, args -> Memory.removeFact(ctx, args.optString("topic")) },

        Tool(
            name = "save_skill",
            description = "Save or update a reusable routine so you can do it again later. " +
                "Use a short name, a one-line description of when to use it, and clear step-by-step instructions.",
            params = mapOf(
                "name" to "Short skill name, e.g. morning routine",
                "description" to "When to use this skill",
                "instructions" to "Step-by-step instructions, including which tools to call"
            )
        ) { ctx, args ->
            Memory.saveSkill(ctx, args.optString("name"), args.optString("description"), args.optString("instructions"))
        },

        Tool(
            name = "use_skill",
            description = "Get the saved steps for a skill you have learned, then follow them.",
            params = mapOf("name" to "The skill's name")
        ) { ctx, args -> Memory.useSkill(ctx, args.optString("name")) },

        Tool(
            name = "delete_skill",
            description = "Delete a saved skill.",
            params = mapOf("name" to "The skill's name")
        ) { ctx, args -> Memory.deleteSkill(ctx, args.optString("name")) },

        // ADD NEW TOOLS HERE
    )

    fun schema(): JSONArray = customSchema().also { arr ->
        if (Config.CODE_EXECUTION) arr.put(codeExecSchema())
        if (Config.WEB_SEARCH) {
            arr.put(
                JSONObject()
                    .put("type", "web_search_20250305")
                    .put("name", "web_search")
                    .put("max_uses", Config.WEB_SEARCH_MAX_USES)
            )
        }
    }

    private fun codeExecSchema() = JSONObject().put("type", Config.CODE_EXEC_TOOL).put("name", "code_execution")

    private fun customSchema(): JSONArray = JSONArray().also { arr ->
        for (t in all) {
            val props = JSONObject()
            t.params.forEach { (k, v) -> props.put(k, JSONObject().put("type", "string").put("description", v)) }
            arr.put(
                JSONObject()
                    .put("name", t.name)
                    .put("description", t.description)
                    .put(
                        "input_schema", JSONObject()
                            .put("type", "object")
                            .put("properties", props)
                            .put("required", JSONArray(t.params.keys.toList()))
                    )
            )
        }
    }

    fun run(ctx: Context, name: String, input: JSONObject): String =
        all.firstOrNull { it.name == name }?.run?.invoke(ctx, input) ?: "Unknown tool: $name"
}
